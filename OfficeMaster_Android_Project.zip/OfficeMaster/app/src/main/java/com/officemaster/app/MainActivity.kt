package com.officemaster.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var darkMode = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView


    private val OPEN_REQUEST = 1001
    private val CREATE_REQUEST = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val bg = if (darkMode) Color.rgb(24, 27, 33) else Color.rgb(246, 248, 251)
        val fg = if (darkMode) Color.WHITE else Color.rgb(25, 32, 43)
        val card = if (darkMode) Color.rgb(39, 44, 53) else Color.WHITE

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(bg)
        }

        val header = TextView(this).apply {
            text = "Office Master"
            textSize = 28f
            setTextColor(fg)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Мобильный офис • документы, таблицы и печать"
            textSize = 14f
            setTextColor(if (darkMode) Color.LTGRAY else Color.DKGRAY)
            setPadding(0, 6, 0, 22)
        }
        root.addView(subtitle)

        addAction("＋  Открыть документ", "DOC, DOCX, XLS, XLSX, PPT, PPTX, PDF и другие") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, OPEN_REQUEST)
        }
        addAction("▤  Создать текстовый документ", "Создаёт файл TXT в выбранной папке") {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/plain"
                putExtra(Intent.EXTRA_TITLE, "Новый документ.txt")
            }
            startActivityForResult(intent, CREATE_REQUEST)
        }
        addAction("▦  Таблицы и электронные книги", "Открыть XLS, XLSX, ODS или CSV") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, OPEN_REQUEST)
        }
        addAction("▣  Презентации", "Открыть PPT, PPTX или ODP") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, OPEN_REQUEST)
        }
        addAction("☼  Светлая / тёмная тема", "Переключить оформление приложения") {
            darkMode = !darkMode
            render()
        }

        status = TextView(this).apply {
            text = "Выберите действие. Файлы открываются в совместимом приложении, установленном на телефоне."
            textSize = 13f
            setTextColor(if (darkMode) Color.LTGRAY else Color.DKGRAY)
            setPadding(4, 18, 4, 0)
        }
        root.addView(status)
        val note = TextView(this).apply {
            text = "\nВажно: это стартовая версия оболочки. Для редактирования DOCX/XLSX/PPTX и полного набора офисных функций потребуется подключить офисный движок (например, Collabora или ONLYOFFICE). Печать выполняется через приложение, открывшее документ, и системную службу печати Android."
            textSize = 12f
            setTextColor(if (darkMode) Color.LTGRAY else Color.GRAY)
            setPadding(4, 16, 4, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun addAction(title: String, description: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(if (darkMode) Color.rgb(39, 44, 53) else Color.WHITE)
            elevation = 2f
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(if (darkMode) Color.WHITE else Color.rgb(25, 32, 43))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val d = TextView(this).apply {
            text = description
            textSize = 12f
            setTextColor(if (darkMode) Color.LTGRAY else Color.DKGRAY)
            setPadding(0, 5, 0, 0)
        }
        box.addView(t); box.addView(d)
        box.setOnClickListener { action() }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 }
        root.addView(box, params)
    }


    @Deprecated("Uses the classic Android activity result API for a dependency-free starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == CREATE_REQUEST) {
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write("Новый документ Office Master\\n".toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(this, "Документ создан", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось создать документ", Toast.LENGTH_LONG).show()
                return
            }
        }
        openWithHandler(uri)
    }

    private fun openWithHandler(uri: Uri) {
        val mime = contentResolver.getType(uri) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "Открыть документ"))
        } catch (_: Exception) {
            Toast.makeText(this, "Не найдено приложение для этого формата", Toast.LENGTH_LONG).show()
        }
    }
}
